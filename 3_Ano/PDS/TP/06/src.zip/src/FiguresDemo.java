import java.util.HashMap;
import java.util.Map;

// Abstract prototype for Figure
abstract class Figure implements Cloneable {
    protected String description;
    protected String color;

    public Figure(String description, String color) {
        this.description = description;
        this.color = color;
    }

    // Clone method
    @Override
    public Figure clone() throws CloneNotSupportedException {
        return (Figure) super.clone();
    }

    // Getters for description and color
    public String getDescription() {
        return description;
    }

    public String getColor() {
        return color;
    }
}

// Concrete prototype for Circle
class Circle extends Figure {
    public Circle(String color) {
        super("Circle", color);
    }
}

// Concrete prototype for Rectangle
class Rectangle extends Figure {
    public Rectangle(String color) {
        super("Rectangle", color);
    }
}

// Concrete prototype for Triangle
class Triangle extends Figure {
    public Triangle(String color) {
        super("Triangle", color);
    }
}

// Prototype factory
class FigureFactory {
    private final Map<String, Figure> prototypes = new HashMap<>();

    // Register prototypes
    public void registerPrototype(String key, Figure prototype) {
        prototypes.put(key, prototype);
    }

    // Clone prototype by key
    public Figure cloneFigure(String key) throws CloneNotSupportedException {
        Figure prototype = prototypes.get(key);
        if (prototype != null) {
            return prototype.clone();
        }
        return null;
    }
}

public class FiguresDemo {
    public static void main(String[] args) throws CloneNotSupportedException {
        // Create prototype instances for figures
        Figure circlePrototype = new Circle("Red");
        Figure rectanglePrototype = new Rectangle("Blue");
        Figure trianglePrototype = new Triangle("Green");

        // Create factory for cloning figures
        FigureFactory factory = new FigureFactory();
        factory.registerPrototype("Circle", circlePrototype);
        factory.registerPrototype("Rectangle", rectanglePrototype);
        factory.registerPrototype("Triangle", trianglePrototype);

        // Clone figures using factory
        Figure clonedCircle = factory.cloneFigure("Circle");
        Figure clonedRectangle = factory.cloneFigure("Rectangle");
        Figure clonedTriangle = factory.cloneFigure("Triangle");

        // Output cloned figures
        System.out.println("Cloned Circle: " + clonedCircle.getDescription() + ", Color: " + clonedCircle.getColor());
        System.out.println("Cloned Rectangle: " + clonedRectangle.getDescription() + ", Color: " + clonedRectangle.getColor());
        System.out.println("Cloned Triangle: " + clonedTriangle.getDescription() + ", Color: " + clonedTriangle.getColor());
    }
}
