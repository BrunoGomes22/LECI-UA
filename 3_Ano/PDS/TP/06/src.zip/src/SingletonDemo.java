class Singleton {
    // Private static instance variable
    private static Singleton instance = new Singleton();;

    // Private constructor to prevent external instantiation
    private Singleton() {
        // Initialization code
        System.out.println("Singleton instance created");
    }

    // Public static method to access the singleton instance
    public static Singleton getInstance() {
        return instance;
    }

    // Public method to demonstrate singleton functionality
    public void showMessage() {
        System.out.println("Hello from Singleton instance!");
    }
}

public class SingletonDemo {
    public static void main(String[] args) {
        // Get the singleton instance
        Singleton singleton1 = Singleton.getInstance();
        Singleton singleton2 = Singleton.getInstance();

        // Check if both instances are the same
        System.out.println("Are both instances the same? " + (singleton1 == singleton2));

        // Call a method on the singleton instance
        singleton1.showMessage();
    }
}
