// Product class representing a computer
class Computer {
    private String cpu;
    private int ram;
    private int storage;

    public Computer(String cpu, int ram, int storage) {
        this.cpu = cpu;
        this.ram = ram;
        this.storage = storage;
    }

    public String toString() {
        return "Computer: CPU=" + cpu + ", RAM=" + ram + "GB, Storage=" + storage + "GB";
    }
}

// Builder interface defining methods for building a computer
interface ComputerBuilder {
    void setCPU(String cpu);
    void setRAM(int ram);
    void setStorage(int storage);
    Computer build();
}

// Concrete builder class implementing the ComputerBuilder interface
class DesktopBuilder implements ComputerBuilder {
    private String cpu;
    private int ram;
    private int storage;

    @Override
    public void setCPU(String cpu) {
        this.cpu = cpu;
    }

    @Override
    public void setRAM(int ram) {
        this.ram = ram;
    }

    @Override
    public void setStorage(int storage) {
        this.storage = storage;
    }

    @Override
    public Computer build() {
        return new Computer(cpu, ram, storage);
    }
}

// Concrete builder class to create the laptop computer
class LaptopBuilder implements ComputerBuilder {
    private String cpu;
    private int ram;
    private int storage;

    @Override
    public void setCPU(String cpu) {
        this.cpu = cpu;
    }

    @Override
    public void setRAM(int ram) {
        this.ram = ram;
    }

    @Override
    public void setStorage(int storage) {
        this.storage = storage;
    }

    @Override
    public Computer build() {
        return new Computer(cpu, ram, storage);
    }
}

// Director class responsible for constructing the computer
class ComputerDirector {
    private ComputerBuilder builder;

    public ComputerDirector(ComputerBuilder builder) {
        this.builder = builder;
    }

    public void construct(String cpu, int ram, int storage) {
        builder.setCPU(cpu);
        builder.setRAM(ram);
        builder.setStorage(storage);
    }
}

// builder for the server computer
class ServerBuilder implements ComputerBuilder {
    private String cpu;
    private int ram;
    private int storage;

    @Override
    public void setCPU(String cpu) {
        this.cpu = cpu;
    }

    @Override
    public void setRAM(int ram) {
        this.ram = ram;
    }

    @Override
    public void setStorage(int storage) {
        this.storage = storage;
    }

    @Override
    public Computer build() {
        return new Computer(cpu, ram, storage);
    }
}

// Main class to demonstrate the usage of the Builder pattern
public class ComputerDemo {
    public static void main(String[] args) {
        // Create a DesktopBuilder instance
        ComputerBuilder desktopBuilder = new DesktopBuilder();

        // Create a ComputerDirector instance with the DesktopBuilder
        ComputerDirector director = new ComputerDirector(desktopBuilder);

        // Construct a desktop computer with specific configurations
        director.construct("Intel Core i7", 16, 512);

        // Build the computer using the builder
        Computer desktopComputer = desktopBuilder.build();

        // Output the constructed computer
        System.out.println(desktopComputer);

        // Create a LaptopBuilder instance
        ComputerBuilder laptopBuilder = new LaptopBuilder();

        // Create a ComputerDirector instance with the LaptopBuilder
        director = new ComputerDirector(laptopBuilder);

        // Construct a laptop computer with specific configurations
        director.construct("Intel Core i5", 8, 256);

        // Build the computer using the builder
        Computer laptopComputer = laptopBuilder.build();

        // Output the constructed computer
        System.out.println(laptopComputer);

        // Create a ServerBuilder instance
        ComputerBuilder serverBuilder = new ServerBuilder();

        // Create a ComputerDirector instance with the ServerBuilder
        director = new ComputerDirector(serverBuilder);

        // Construct a server computer with specific configurations
        director.construct("Intel Xeon", 64, 1024);

        // Build the computer using the builder
        Computer serverComputer = serverBuilder.build();

        // Output the constructed computer
        System.out.println(serverComputer);

    }
}
