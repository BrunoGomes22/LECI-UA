// NutritionFacts class with Builder pattern
class NutritionFacts {
    private final int servingSize;  // Required
    private final int servings;     // Required
    private final int calories;     // Optional
    private final int fat;          // Optional
    private final int carbohydrates;// Optional
    private final int protein;      // Optional

    private NutritionFacts(Builder builder) {
        this.servingSize = builder.servingSize;
        this.servings = builder.servings;
        this.calories = builder.calories;
        this.fat = builder.fat;
        this.carbohydrates = builder.carbohydrates;
        this.protein = builder.protein;
    }

    // Getters for nutritional facts
    public int getServingSize() {
        return servingSize;
    }

    public int getServings() {
        return servings;
    }

    public int getCalories() {
        return calories;
    }

    public int getFat() {
        return fat;
    }

    public int getCarbohydrates() {
        return carbohydrates;
    }

    public int getProtein() {
        return protein;
    }

    // Builder class for NutritionFacts
    public static class Builder {
        // Required parameters
        private final int servingSize;
        private final int servings;

        // Optional parameters with default values
        private int calories = 0;
        private int fat = 0;
        private int carbohydrates = 0;
        private int protein = 0;

        // Constructor with required parameters
        public Builder(int servingSize, int servings) {
            this.servingSize = servingSize;
            this.servings = servings;
        }

        // Methods to set optional parameters
        public Builder calories(int calories) {
            this.calories = calories;
            return this;
        }

        public Builder fat(int fat) {
            this.fat = fat;
            return this;
        }

        public Builder carbohydrates(int carbohydrates) {
            this.carbohydrates = carbohydrates;
            return this;
        }

        public Builder protein(int protein) {
            this.protein = protein;
            return this;
        }

        // Method to build NutritionFacts object
        public NutritionFacts build() {
            return new NutritionFacts(this);
        }
    }

    // Example usage
    public static void main(String[] args) {
        // Create a NutritionFacts object using the Builder
        NutritionFacts cocaCola = new NutritionFacts.Builder(240, 8)
                .calories(100)
                .fat(0)
                .carbohydrates(27)
                .protein(0)
                .build();

        // Output nutritional facts
        System.out.println("Nutritional Facts for Coca-Cola:");
        System.out.println("Serving Size: " + cocaCola.getServingSize() + " ml");
        System.out.println("Servings: " + cocaCola.getServings());
        System.out.println("Calories: " + cocaCola.getCalories());
        System.out.println("Fat: " + cocaCola.getFat() + " g");
        System.out.println("Carbohydrates: " + cocaCola.getCarbohydrates() + " g");
        System.out.println("Protein: " + cocaCola.getProtein() + " g");
    }
}

