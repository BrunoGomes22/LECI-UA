
import java.util.ArrayList;
import java.util.List;

interface KmPercorridosInterface {
    void trajeto(int quilometros);

    int ultimoTrajeto();

    int distanciaTotal();
}

abstract class Veiculo implements KmPercorridosInterface {
    private String matricula, marca, modelo;
    private int cv;
    private int kmTotal;
    private int ultimoKm;

    public Veiculo(String matricula, String marca, String modelo, int cv) {
        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
        this.cv = cv;
        this.kmTotal = 0;
        this.ultimoKm = 0;

    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getMatricula() {
        return this.matricula;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getMarca() {
        return this.marca;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getModelo() {
        return this.modelo;
    }

    public void setCv(int cv) {
        this.cv = cv;
    }

    public int getCv() {
        return this.cv;
    }

    @Override
    public void trajeto(int quilometros) {
        this.kmTotal += quilometros;
        this.ultimoKm = quilometros;
    }

    @Override
    public int ultimoTrajeto() {
        return ultimoKm;
    }

    @Override
    public int distanciaTotal() {
        return kmTotal;
    }

    @Override
    public String toString() {
        return "Veiculo [matricula=" + matricula + ", marca=" + marca + ", modelo=" + modelo + ", cv=" + cv + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((matricula == null) ? 0 : matricula.hashCode());
        result = prime * result + ((marca == null) ? 0 : marca.hashCode());
        result = prime * result + ((modelo == null) ? 0 : modelo.hashCode());
        result = prime * result + cv;
        result = prime * result + kmTotal;
        result = prime * result + ultimoKm;
        return result;
    }

}

class Motociclo extends Veiculo {
    private String tipo;

    public Motociclo(String matricula, String marca, String modelo, int cv, String tipo) {
        super(matricula, marca, modelo, cv);
        this.tipo = tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getTipo() {
        return this.tipo;
    }

    @Override
    public String toString() {
        return "Motociclo [matricula=" + getMatricula() + ", marca=" + getMarca() + ", modelo=" + getModelo() + ", cv="
                + getCv() + ", tipo=" + tipo + "]";
    }

}

class AutomovelLigeiro extends Veiculo {

    private int Nbagageira;
    private String Nquadro;

    public AutomovelLigeiro(String matricula, String marca, String modelo, int cv, String nquadro, int nbagageira) {
        super(matricula, marca, modelo, cv);
        this.Nquadro = nquadro;
        this.Nbagageira = nbagageira;
    }

    public String getNquadro() {
        return this.Nquadro;
    }

    public void setNquadro(String Nquadro) {
        this.Nquadro = Nquadro;
    }

    public int getNbagageira() {
        return this.Nbagageira;
    }

    public void setNbagageira(int Nbagageira) {
        this.Nbagageira = Nbagageira;
    }

    @Override
    public String toString() {
        return "AutomovelLigeiro [matricula=" + getMatricula() + ", marca=" + getMarca() + ", modelo=" + getModelo()
                + ", cv=" + getCv() + ", Nbagageira=" + Nbagageira + ", Nquadro=" + Nquadro + "]";
    }

}

class Taxi extends AutomovelLigeiro {
    private String licenca;

    public Taxi(String matricula, String marca, String modelo, int cv, String nquadro, int nbagageira, String licenca) {
        super(matricula, marca, modelo, cv, nquadro, nbagageira);
        this.licenca = licenca;
    }

    public String getLicenca() {
        return this.licenca;
    }

    public void setLicenca(String licenca) {
        this.licenca = licenca;
    }

    @Override
    public String toString() {
        return "Taxi [matricula=" + getMatricula() + ", marca=" + getMarca() + ", modelo=" + getModelo() + ", cv="
                + getCv() + ", licenca=" + licenca + "]";
    }

}

class PesadoMercadorias extends Veiculo {
    private double peso, Cmax;
    private String Nquadro;

    public PesadoMercadorias(String matricula, String marca, String modelo, int cv, String nquadro, double peso,
            double cmax) {
        super(matricula, marca, modelo, cv);
        this.peso = peso;
        this.Cmax = cmax;
        this.Nquadro = nquadro;
    }

    public double getPeso() {
        return this.peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getCmax() {
        return this.Cmax;
    }

    public void setCmax(double Cmax) {
        this.Cmax = Cmax;
    }

    public String getNquadro() {
        return this.Nquadro;
    }

    public void setNquadro(String Nquadro) {
        this.Nquadro = Nquadro;
    }

    @Override
    public String toString() {
        return "PesadoMercadorias [matricula=" + getMatricula() + ", marca=" + getMarca() + ", modelo=" + getModelo()
                + ", cv=" + getCv() + ", peso=" + peso + ", Cmax=" + Cmax + ", Nquadro=" + Nquadro + "]";
    }

}

class PesadoPassageiros extends Veiculo {
    private double peso;
    private int NMpass;
    private String Nquadro;

    public PesadoPassageiros(String matricula, String marca, String modelo, int cv, double peso, String nquadro,
            int nMpass) {
        super(matricula, marca, modelo, cv);
        this.peso = peso;
        Nquadro = nquadro;
        NMpass = nMpass;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getNquadro() {
        return Nquadro;
    }

    public void setNquadro(String nquadro) {
        Nquadro = nquadro;
    }

    public int getNMpass() {
        return NMpass;
    }

    public void setNMpass(int nMpass) {
        NMpass = nMpass;
    }

    @Override
    public String toString() {
        return "PesadoPassageiros [matricula=" + getMatricula() + ", marca=" + getMarca() + ", modelo=" + getModelo()
                + ", cv=" + getCv() + ", peso=" + peso + ", NMpass=" + NMpass + ", Nquadro=" + Nquadro + "]";
    }

}

class EAViaturas {
    private String nome, Cpostal, email;
    private List<Veiculo> veiculo;

    public EAViaturas(String nome, String cpostal, String email) {
        this.nome = nome;
        this.Cpostal = cpostal;
        this.email = email;
        this.veiculo = new ArrayList<>();
    }

    public void addVeiculo(Veiculo v) {
        this.veiculo.add(v);
    }

    public void removeVeiculo(Veiculo v) {
        this.veiculo.remove(v);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpostal() {
        return Cpostal;
    }

    public void setCpostal(String cpostal) {
        Cpostal = cpostal;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<Veiculo> getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(List<Veiculo> veiculo) {
        this.veiculo = veiculo;
    }

    @Override
    public String toString() {
        return "{" +
                " nome='" + getNome() + "'" +
                ", Cpostal='" + getCpostal() + "'" +
                ", email='" + getEmail() + "'" +
                ", veiculo='" + getVeiculo() + "'" +
                "}";
    }

}

interface VeiculoEletrico {
    int autonomia(); // devolve autonomia restante

    void carregar(int percentagem); // simula um carregamento até ‘percentagem’
}

class PPEletrico extends PesadoPassageiros implements VeiculoEletrico {
    private int BAtual, BMax;
    private int PAtual;

    public PPEletrico(String matricula, String marca, String modelo, int cv, double peso, String nquadro, int nMpass,
            int bAtual, int bMax) {
        super(matricula, marca, modelo, cv, peso, nquadro, nMpass);
        this.BAtual = bAtual;
        this.BMax = bMax;
    }

    public int getBAtual() {
        return BAtual;
    }

    public void setBAtual(int bAtual) {
        BAtual = bAtual;
    }

    public int getBMax() {
        return BMax;
    }

    public int getPercentagemAtual() {
        return PAtual;
    }

    @Override
    public int autonomia() {
        // assumindo que 100% da 200km
        int km = PAtual * 2;

        return km;
    }

    @Override
    public void carregar(int percentagem) {
        // 1% demora 5min
        int Prestante = percentagem - PAtual;
        System.out.println("Vai demorar " + Prestante * 5 + " min");
    }

    public void setBMax(int bMax) {
        BMax = bMax;
    }

}

class ALEletrico extends AutomovelLigeiro implements VeiculoEletrico {
    private int BAtual, BMax;
    private int PAtual;


    public ALEletrico(String matricula, String marca, String modelo, int cv, String nquadro, int nbagageira, int bAtual,
            int bMax) {
        super(matricula, marca, modelo, cv, nquadro, nbagageira);
        this.BAtual = bAtual;
        this.BMax = bMax;
    }

    public int getBAtual() {
        return BAtual;
    }

    public void setBAtual(int bAtual) {
        this.BAtual = bAtual;
    }

    public int getBMax() {
        return BMax;
    }

    public int getPercentagemAtual() {
        return PAtual;
    }

    @Override
    public int autonomia() {
        // assumindo que 100% da 100km
        int km = PAtual;

        return km;
    }

    @Override
    public void carregar(int percentagem) {
        // 1% demora 7min
        int Prestante = percentagem - PAtual;
        System.out.println("Vai demorar " + Prestante * 7 + " min");
    }

    public void setBMax(int bMax) {
        BMax = bMax;
    }
}

class Rental {
    private String name;
    private String postal;
    private String email;
    private ArrayList<Veiculo> stock;

    Rental(){}

    Rental(String name, String postal, String email){
        this.setName(name);
        this.setPostal(postal);
        this.setEmail(email);
        this.stock = new ArrayList<Veiculo>();
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPostal(String postal) {
        this.postal = postal;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPostal() {
        return postal;
    }

    public ArrayList<Veiculo> getStock() {
        return stock;
    }

    public void addVeiculo(Veiculo v) {
        this.stock.add(v);
    }
}

// Factory to create all types of vehicles
// the factory should have a method for each type of vehicle with the necessary parameters

class VehicleFactory {
    public static Motociclo createMotociclo(String matricula, String marca, String modelo, int cv, String tipo) {
        return new Motociclo(matricula, marca, modelo, cv, tipo);
    }
    public static AutomovelLigeiro createAutomovelLigeiro(String matricula, String marca, String modelo, int cv, String nquadro, int nbagageira) {
        return new AutomovelLigeiro(matricula, marca, modelo, cv, nquadro, nbagageira);
    }
    public static Taxi createTaxi(String matricula, String marca, String modelo, int cv, String nquadro, int nbagageira, String licenca) {
        return new Taxi(matricula, marca, modelo, cv, nquadro, nbagageira, licenca);
    }
    public static PesadoMercadorias createPesadoMercadorias(String matricula, String marca, String modelo, int cv, String nquadro, double peso, double cmax) {
        return new PesadoMercadorias(matricula, marca, modelo, cv, nquadro, peso, cmax);
    }
    public static PesadoPassageiros createPesadoPassageiros(String matricula, String marca, String modelo, int cv, double peso, String nquadro, int nMpass) {
        return new PesadoPassageiros(matricula, marca, modelo, cv, peso, nquadro, nMpass);
    }
    public static PPEletrico createPPEletrico(String matricula, String marca, String modelo, int cv, double peso, String nquadro, int nMpass, int bAtual, int bMax) {
        return new PPEletrico(matricula, marca, modelo, cv, peso, nquadro, nMpass, bAtual, bMax);
    }
    public static ALEletrico createALEletrico(String matricula, String marca, String modelo, int cv, String nquadro, int nbagageira, int bAtual, int bMax) {
        return new ALEletrico(matricula, marca, modelo, cv, nquadro, nbagageira, bAtual, bMax);
    }
}

public class EmpresaAluguer {
    public static void main(String[] args) {

        Rental r = new Rental("Rental", "1234-567", "a@ua.pt");
        r.addVeiculo(VehicleFactory.createMotociclo("00-AB-12", "Honda", "CBR 600", 100, "desportivo"));
        r.addVeiculo(VehicleFactory.createAutomovelLigeiro("22-CD-34", "Volkswagen", "Golf", 110, "ABC123456789", 350));
        r.addVeiculo(VehicleFactory.createTaxi("44-EF-56", "Mercedes-Benz", "E-Class", 150, "GHI123456789", 400, "TAXI123"));
        r.addVeiculo(VehicleFactory.createPPEletrico("77-HI-89", "Tesla", "Model X", 500, 2000, "PPE123456789", 50, 100, 200));
        r.addVeiculo(VehicleFactory.createALEletrico("88-IJ-90", "Tesla", "Model 3", 500, "ALE123456789", 500, 1000, 2000));
        r.addVeiculo(VehicleFactory.createPesadoMercadorias("66-GH-78", "Volvo", "FH", 500, "MNO123456789", 20000, 40000));
        r.addVeiculo(VehicleFactory.createPesadoPassageiros("99-JK-00", "Volvo", "FH", 500, 2000, "PPE123456789", 50));


        for(Veiculo v : r.getStock()){
            System.out.println(v);
        }
    }

}