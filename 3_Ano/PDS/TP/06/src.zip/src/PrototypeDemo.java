import java.util.HashMap;
import java.util.Map;

// Prototype interface
interface Prototype {
    Prototype clone();
    String getDescription();
}

// Concrete prototype 1
class ConcretePrototype1 implements Prototype {
    private final String description;

    public ConcretePrototype1(String description) {
        this.description = description;
    }

    @Override
    public Prototype clone() {
        return new ConcretePrototype1(description);
    }

    @Override
    public String getDescription() {
        return description;
    }
}

// Concrete prototype 2
class ConcretePrototype2 implements Prototype {
    private final String description;

    public ConcretePrototype2(String description) {
        this.description = description;
    }

    @Override
    public Prototype clone() {
        return new ConcretePrototype2(description);
    }

    @Override
    public String getDescription() {
        return description;
    }
}

// Prototype registry
class PrototypeRegistry {
    private final Map<String, Prototype> prototypes = new HashMap<>();

    public void registerPrototype(String key, Prototype prototype) {
        prototypes.put(key, prototype);
    }

    public Prototype clonePrototype(String key) {
        Prototype prototype = prototypes.get(key);
        if (prototype != null) {
            return prototype.clone();
        }
        return null;
    }
}

public class PrototypeDemo {
    public static void main(String[] args) {
        // Create prototype instances
        Prototype prototype1 = new ConcretePrototype1("Prototype 1");
        Prototype prototype2 = new ConcretePrototype2("Prototype 2");

        // Register prototypes in the registry
        PrototypeRegistry registry = new PrototypeRegistry();
        registry.registerPrototype("P1", prototype1);
        registry.registerPrototype("P2", prototype2);

        // Clone prototypes from the registry
        Prototype clonedPrototype1 = registry.clonePrototype("P1");
        Prototype clonedPrototype2 = registry.clonePrototype("P2");

        // Output cloned prototypes
        System.out.println("Cloned Prototype 1: " + clonedPrototype1.getDescription());
        System.out.println("Cloned Prototype 2: " + clonedPrototype2.getDescription());
    }
}
