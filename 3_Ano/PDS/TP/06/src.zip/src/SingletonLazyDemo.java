class SingletonLazy {
    // Private static instance variable
    private static SingletonLazy instance;

    // Private constructor to prevent external instantiation
    private SingletonLazy() {
        // Initialization code
        System.out.println("Singleton instance created");
    }

    // Public static method to access the singleton instance with lazy initialization
    public static SingletonLazy getInstance() {
        // Double-checked locking for thread safety
        if (instance == null) {
                instance = new SingletonLazy();
            }
        return instance;
    }

    // Public method to demonstrate singleton functionality
    public void showMessage() {
        System.out.println("Hello from Singleton instance!");
    }
}

public class SingletonLazyDemo {
    public static void main(String[] args) {
        // Get the singleton instance
        SingletonLazy singleton1 = SingletonLazy.getInstance();
        SingletonLazy singleton2 = SingletonLazy.getInstance();

        // Check if both instances are the same
        System.out.println("Are both instances the same? " + (singleton1 == singleton2));

        // Call a method on the singleton instance
        singleton1.showMessage();
    }
}
