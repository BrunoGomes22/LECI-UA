// Product class representing a computer
class ComputerV2 {
    private String cpu;
    private int ram;
    private int storage;

    public ComputerV2(String cpu, int ram, int storage) {
        this.cpu = cpu;
        this.ram = ram;
        this.storage = storage;
    }

    // implement setters
    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    public void setRam(int ram) {
        this.ram = ram;
    }

    public void setStorage(int storage) {
        this.storage = storage;
    }

    public String toString() {
        return "Computer: CPU=" + cpu + ", RAM=" + ram + "GB, Storage=" + storage + "GB";
    }
}

// Builder interface defining methods for building a computer
interface ComputerBuilderV2 {
    void setCPU(String cpu);
    void setRAM(int ram);
    void setStorage(int storage);
    ComputerV2 get();
}

// Concrete builder class implementing the ComputerBuilder interface
class DesktopBuilderV2 implements ComputerBuilderV2 {
    private ComputerV2 computer;

    public DesktopBuilderV2() {
        computer = new ComputerV2("", 0, 0);
    }

    @Override
    public void setCPU(String cpu) {
        computer.setCpu(cpu);
    }

    @Override
    public void setRAM(int ram) {
        computer.setRam(ram);
    }

    @Override
    public void setStorage(int storage) {
        computer.setStorage(storage);
    }

    @Override
    public ComputerV2 get() {
        return computer;
    }
}

// Director class responsible for constructing the computer
class ComputerDirectorV2 {
    private ComputerBuilderV2 builder;

    public void setBuilder(ComputerBuilderV2 builder) {
        this.builder = builder;
    }

    public void construct(String cpu, int ram, int storage) {
        builder.setCPU(cpu);
        builder.setRAM(ram);
        builder.setStorage(storage);
    }
}

// Main class to demonstrate the usage of the Builder pattern
public class ComputerDemoV2 {
    public static void main(String[] args) {
        // Create a DesktopBuilder instance
        DesktopBuilderV2 desktopBuilder = new DesktopBuilderV2();

        // Create a ComputerDirector instance
        ComputerDirectorV2 director = new ComputerDirectorV2();

        // Set the builder for the director
        director.setBuilder(desktopBuilder);

        // Construct a desktop computer with specific configurations
        director.construct("Intel Core i7", 16, 512);

        // Build the computer using the builder
        ComputerV2 desktopComputer = desktopBuilder.get();

        // Output the constructed computer
        System.out.println(desktopComputer);
    }
}

