create table Professor(
N_de_funcionario char(9) not null,
Nome varchar(20) not null,
Cc	 varchar(9) not null,
Morada varchar(20) not null,
Data_de_nascimento date not null,
Email varchar(320) not null,
Contacto_telefonico char(9) not null
primary key (N_de_funcionario)
);

create table Turma(
Identificador char(9) not null,
Designacao varchar(9) not null,
N_de_alunos int not null,
Fk_professor char(9) not null,
primary key (Identificador)
);

create table Tem(
Identificador_turma char(9) not null,
Identificador_atividade char(9) not null,
primary key(Identificador_turma, Identificador_atividade)
);

create table Turma_Ano_Letivo(
Turma_ano_letivo char(9) not null,
Identificador_Turma_letivo char(9) not null,
primary key(Identificador_Turma_letivo)
);

create table Atividade(
Identificador char(9) not null,
Custo money not null,
Designacao varchar(9) not null,
Fk_professor_atividade char(9) not null,
primary key(Identificador)
);

create table Atividade_ano_letivo(
Atividade_ano_letivo char(9) not null,
Identificador_atividade_ano_letivo char(9) not null,
primary key(Atividade_ano_letivo, Identificador_atividade_ano_letivo)
);

create table Frequenta(
Identificador_atividade_frequenta char(9) not null,
Cartao_de_cidadao_aluno char(9) not null,
primary key(Identificador_atividade_frequenta, Cartao_de_cidadao_aluno)
);

create table Aluno(
Nome	varchar(20) not null,
Cartao_de_Cidadao char(9) not null,
Data_de_nascimento date not null,
Fk_Entidade char(9) not null,
primary key(Cartao_de_Cidadao)
);

create table Entidade_para_levantar_o_aluno(
Nome	varchar(20) not null,
Cartao_de_cidadao char(9) not null,
Morada varchar(20) not null,
Contacto_telefonico char(9) not null,
Data_de_nascimento date not null,
Email varchar(320) not null,
primary key(Cartao_de_cidadao)
);

create table Entidade_relacao_aluno(
Entidade_relacao_aluno	varchar(10) not null,
Cartao_de_cidadao_Entidade char(9) not null,
primary key(Entidade_relacao_aluno)
);

create table Encarregado_de_educacao(
Cartao_de_cidadao_educacao char(9) not null,
primary key(Cartao_de_cidadao_educacao)
);

create table Pessoa_com_autorizacao(
Cartao_de_cidadao_autorizacao char(9) not null,
primary key(Cartao_de_cidadao_autorizacao)
);

alter table Turma
add constraint Fk_professor
foreign key (Fk_professor) references Professor(N_de_funcionario)

alter table Tem
add constraint Identificador_turma
foreign key (Identificador_turma) references Turma(Identificador)

alter table Tem
add constraint Identificador_atividade
foreign key (Identificador_atividade) references Atividade(Identificador)

alter table Turma_Ano_Letivo
add constraint Identificador_Turma_Letivo
foreign key (Identificador_Turma_Letivo) references Turma(Identificador)

alter table Atividade
add constraint Fk_professor_atividade
foreign key (Fk_professor_atividade) references Professor(N_de_funcionario)

alter table Atividade_ano_letivo
add constraint Identificador_atividade_ano_letivo
foreign key (Identificador_atividade_ano_letivo) references Atividade(Identificador)

alter table Frequenta
add constraint Identificador_atividade_frequenta
foreign key (Identificador_atividade_frequenta) references Atividade(Identificador)

alter table Frequenta
add constraint Cartao_de_cidadao_aluno
foreign key (Cartao_de_cidadao_aluno) references Aluno(Cartao_de_cidadao)

alter table Aluno
add constraint Fk_entidade
foreign key (Fk_entidade) references Entidade_para_levantar_o_aluno(Cartao_de_cidadao)

alter table Entidade_relacao_aluno
add constraint Cartao_de_cidadao_Entidade
foreign key (Cartao_de_cidadao_Entidade) references Entidade_para_levantar_o_aluno(Cartao_de_cidadao)

alter table Encarregado_de_educacao
add constraint Cartao_de_cidadao_educacao
foreign key (Cartao_de_cidadao_educacao) references Entidade_para_levantar_o_aluno(Cartao_de_cidadao)

alter table Pessoa_com_autorizacao
add constraint Cartao_de_cidadao_autorizacao
foreign key (Cartao_de_cidadao_autorizacao) references Entidade_para_levantar_o_aluno(Cartao_de_cidadao)
