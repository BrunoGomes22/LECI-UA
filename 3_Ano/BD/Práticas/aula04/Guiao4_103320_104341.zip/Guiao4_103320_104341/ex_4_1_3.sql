create table Produto(
C�digo	     int		 not null,
Nome         varchar(15) not null,
Pre�o        int         not null,
Taxa         int         not null,
FK_Encomenda int         not null,
primary key(C�digo),
);


create table Encomenda(
Encomenda_N�mero int        not null,
Data_1           date       not null,
NIF              char(9)    not null,
primary key(Encomenda_N�mero),
);

create table Fornecedor(
NIF char(9)   not null,
Nome varchar(15) not null,
Endere�o int not null,
Fax int not null,
primary key(NIF)
);

create table Fornecedor_Condi��o_Pagamento(
Forn_Cond_Pagamento  int not null,
NIF_Pagamento char(9) not null,
primary key(Forn_Cond_Pagamento)
);

create table Tipo_de_Fornecedor(
FK_Fornecedor char(9) not null,
Designa��o varchar(15) not null,
primary key(Designa��o)
);
alter table Produto
add constraint FK_Encomenda
foreign key (FK_Encomenda) references Encomenda(Encomenda_N�mero)

alter table  Encomenda
add constraint NIF
foreign key (NIF) references Fornecedor(NIF)

alter table Fornecedor_Condi��o_Pagamento
add constraint NIF_Pagamento
foreign key (NIF_Pagamento) references Fornecedor(NIF)

alter table Tipo_de_Fornecedor
add constraint FK_Fornecedor
foreign key (FK_Fornecedor) references Fornecedor(NIF)