create table Medico(
Identificacao char(9) not null,
Nome varchar(20) not null,
Especialidade varchar(20) not null,
primary key(Identificacao)
);

create table Paciente(
N_de_utente char(9) not null,
Nome varchar(20) not null,
Data_de_nascimento date not  null,
endereco varchar(320) not null,
primary key(N_de_utente)
);

create table Prescricao(
Numero char(9) not null,
Date_1 date not null,
Fk_Medico char(9) not null,
Fk_Paciente char(9) not null,
primary key(Numero)
);

create table Processa(
Numero char(9) not null,
Nif char(9) not null
primary key(Numero, Nif)
);

create table Farmacia(
Nif char(9) not null,
Telefone char(9) not null,
Endereco varchar(320) not null,
Nome varchar(20) not null,
primary key(Nif)
);


create table Farmaco(
Formula varchar(20) not null,
Nome_comercial varchar(20) not null,
Fk_companhia_farmaceutica char(15) not null,
primary key(Nome_comercial)
);

create table Companhia_farmaceutica(
N_de_registo_nacional char(15) not null,
Endereco varchar(320) not null,
Nome varchar(20) not null,
Telefone char(9) not null,
primary key(N_de_registo_nacional)
);

create table Vende(
Nif_vende char(9) not null,
Nome_comercial varchar(20) not null,
primary key(Nome_comercial, Nif_vende)
);

alter table Prescricao
add constraint Fk_Medico
foreign key (Fk_Medico) references Medico(Identificacao)

alter table Prescricao
add constraint Fk_Paciente
foreign key (Fk_Paciente) references Paciente(N_de_utente)

alter table Processa
add constraint Numero
foreign key(Numero) references Prescricao(Numero)

alter table Processa
add constraint Nif
foreign key(Nif) references Farmacia(Nif)

alter table Farmaco
add constraint Fk_companhia_farmaceutica
foreign key(Fk_companhia_farmaceutica) references Companhia_farmaceutica(N_de_registo_nacional)

alter table Vende
add constraint Nif_vende
foreign key(Nif_vende) references Farmacia(Nif)

alter table Vende
add constraint Nome_comercial
foreign key(Nome_comercial) references Farmaco(Nome_comercial)
